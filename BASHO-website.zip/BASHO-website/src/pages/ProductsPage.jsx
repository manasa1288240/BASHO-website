import { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import ProductCard from "../components/ProductCard";
import products from "../data/products";
import "../styles/ProductsPage.css";

export default function ProductsPage() {
  const [activeFilter, setActiveFilter] = useState("All");

  const categories = ["All", "Vases", "Bowls", "Mugs", "Planters", "Plates"];

  const filteredProducts =
    activeFilter === "All"
      ? products
      : products.filter((p) => p.category === activeFilter);

  return (
    <div className="products-page">
      <Navbar />

      {/* Hero Header */}
      <section className="products-hero">
        <div className="products-hero-content">
          <h1 className="products-hero-title">Our Collection</h1>
          <p className="products-hero-subtitle">
            Where tradition meets modern simplicity
          </p>
        </div>
      </section>

      {/* Description Section */}
      <section className="products-intro">
        <div className="products-intro-content">
          <h2>Handcrafted with Care</h2>
          <p>
            Our artisans honor centuries-old techniques while creating pieces
            that belong in contemporary homes. Each piece tells a story through
            its texture, glaze, and subtle asymmetry.
          </p>
        </div>
      </section>

      {/* Filter Buttons */}
      <div className="products-filters">
        {categories.map((category) => (
          <button
            key={category}
            className={`filter-btn ${
              activeFilter === category ? "active" : ""
            }`}
            onClick={() => setActiveFilter(category)}
          >
            {category.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <section className="products-grid-section">
        <div className="products-grid">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}